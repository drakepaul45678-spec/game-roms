
open DeltaPatcher.exe
on the original file Select your Mkds rom
on xdelta patch select the patch and click apply patch and done.

Use Mario kart ds (U) Region