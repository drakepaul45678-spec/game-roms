#####  Super Mario Kart - Horizons ##### 

Overview
========

Thank you for downloading Super Mario Kart - Horizons! This is a comprehensive mod for the original Super Mario Kart with tons of new content and features!

Some, but not all of features the mod provides are:
- Custom Title Screen & Demos
- 20 New Tracks & 4 New Battle Tracks
- 8 New course themes, with each track having it's own unique palette; meaning no track looks the same!
- A complete brand new soundtrack! All of the base game songs have been replaced with a new track, including the character victory themes!
- Modified game mechanics, such as new ranking system; advance to the next round by placing 7th and up!
- Custom Cup, Driver Select & Podium Screens.
- Unlockable content: Unlock Mirror Mode and a new difficulty setting!
- Updated Sprites; including all the drivers, course obstacles, items and many more.
- Works on original hardware.

And many more changes; including subtle ones and major ones! 

It's recommended that you read the Game Manual provided with this mod to get a better overview of the new content the hack provides.

If you want to create a physical copy of this hack, I have provided a template of a SNES styled box and a cart label you can use!

The complete soundtrack is also available for listening in your platform of choice!

You can find a download for each of the above in the section below named "Additional Downloads"

Getting Started
===============

In order to play this mod, you need to find a ROM of Super Mario Kart. This ROM needs to be the same one used to generate the patch. Please find **on your own** the No-Intro version, as that was used to make the base patch. Below is the Checksum so you can verify that you have a compatible ROM:

Database match: Super Mario Kart (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 47E103D8398CF5B7CBB42B95DF3A3C270691163B
File/ROM CRC32: CD80DB86


Patching the ROM
----------------

The patch file is in the .bps format, so you need to use the program named "Floating IPS" to apply it. Once you have the program, follow the following steps:
1. Open "flips.exe"
2. Click the "Apply Patch" button.
3. Find the patch file named "Super Mario Kart - Horizons.bps" and select it.
4. Find your copy of the Super Mario Kart ROM and select it.
5. A final window will open, press the "Save" button on the window.
6. A new ROM file should have been created in the directory you chose.
7. Open "Super Mario Kart - Horizons.sfc" (or however you named it) on your favorite SNES emulator or load it into your flash cart of choice.
8. Enjoy!

Additional Download
===================

With the release of the hack, I have provided a set of complimentary files. These are the SNES Game Boxes, SNES Cart Label, Instruction Booklet and the Original Soundtrack, which you can find below:
- Original Soundtrack: https://nsmbhd.net/file/jD1Jz0vNkep7REE2/Super%20Mario%20Kart%20Horizons%20-%20Original%20Soundtrack.zip
- SPC Version of the Soundtrack: https://nsmbhd.net/file/9isvSShWVA0zvQqO/SMK%20-%20Horizons%20SPC%20OST.zip
- Instruction Booklet: https://nsmbhd.net/file/MPdYVjyywGD8bPNz/Super%20Mario%20Kart%20Horizons%20-%20Instructions%20Booklet.pdf
- Game Boxes, Cart Label & Logo: https://nsmbhd.net/file/jUu1SuLnxZDbYvRy/Super%20Mario%20Kart%20Horizons%20-%20Boxes,%20Labels%20&%20Logo.zip

Known Issues
============

Here is a list of some of the issues that I managed to find in the mod. All of these are minor though, and don't really impact gameplay in any way. If you find something more serious, please reach out to Gridatttack so the issue may be fixed.
- There is a graphical glitch right below the middle black bar, and depends on what platform you are playing the mod. On ZSNES, when the character sprites are close to the top, they don't update properly and it looks like a portion of them are stuck, whereas on original hardware, the drivers sprites are cut off by 1 transparent pixel.
- When using a Star and you drive over the cheep cheeps and the piranha plants, on some tracks, you will see that they look like they were duplicated 4 times in a square. This issue stems because originally, the cheep cheeps and piranha plants appeared on stages where the feather item appeared, but some stages where they are featured, the item is not available. This setting conflicts with the behaviour these obstacles should have when being run over with a star.
- When sharp drifting and turning on some tracks lakitu might come down and tell you you are driving in reverse. This is due to the layout and position of the CPU zones. I tried my best so it doesn't seems that you are going in reverse, but sometimes the game thinks you are and you will either see Lakitu coming down or just his shadow for a small section of time.
- The first title screen demo can sometimes desync.
- Some other small issues might have slipped under the radar; hopefully these are small and don't have a big impact!

Questions and Answers
=====================

Q: "Where can I contact you?"
A: You can reach me via discord or youtube. I recommend you join the Super Mario Kart Workshop Discord: https://discord.gg/QNcKNQC

Q: "Where was the hack tested?"
A: The hack was mainly tested on ZSNES. Snes9X and BSNES works fine as well. Assume things like Retroarch, Analogue systems and others works fine as well. In the case for original hardware, it was tested with an FXPAK Pro. Basically, if a platform can run Super Mario Kart just fine, it should work with the ROM as well.

Q: "What tools did you use to make the mod and the assets?"
A: I mainly used Epic Edit to edit the tracks as well as the graphics it allows to edit in the editor. For things that weren't directly editable, I used a Hex Editor to edit the ROM directly. 
Other than that, I mainly used a combination of Paint.NET, GIMP & Asesprite for some custom graphics. The custom music was created with PrixCompose; a tool specifically made to create & program the custom music in the game. 
The Game Boxes, Manuals and Cart Labels were done in Figma.
Trailer was edited and rendered on Davinci Resolve.

Q: "Why did did the hack took so long to complete?"
A: This is due to multiple of reasons, such as not focusing entirely on it (I actually made Sour Music Kart in this time span as well) or other issues out of my control. I also took a decision to wait until the code of the game was understood better so I could expand it with capabilities, which in the end they enhance the hack overall.

Q: "Can I use your custom assets (custom graphics, Music, Sprites, etc.) in my own hack?"
A: Please, DO NOT. Part of my goal to take care in the presentation of this hack is to make it more unique, as a lot of the current Super Mario Kart hacks are too similar, poor quality and don't look good. 
Go make something your own and be original. You may find some assets were ported over from other games. In this case, port them from scratch on your own. 
The themes and music were made specifically for this hack and are cohesive when they are all together, not when they are randomly used in another hack. 
There is also no need to "fix" this hack. If you have a personal problem with it, then just keep it to yourself. If it's something serious, contact me and I will make sure it is fixed. 
I should be around for the foreseeable future; so there should be plenty of time to update the game from my part.

Changelog
=========
Version 1.3
- Fixes time trial issue when using Donkey Kong JR.
- Alters the speed of the AI on Horizon Cup and some other tracks to be a bit easier overall.

Version 1.2
- Fix reintroduced typo on Podium screen.
- Update assets with new box design & include main Logo as a separate file.

Version 1.1
- Fix Mirror Mode unlock Issue.
- Make Jungle Ruin brick tileset with less contrast to be easier to see.
- Fix AI on Rice Terrace 2 to be the slowest when going over water.
- Fix some item probabilities for courses that have feathers.
- Extended wall to Sunrise Ridge 2 to prevent unintented shortcut.
- Fix ROM size to increase compatibility for some platforms.

Credits
=======

Below, I would like to go in depth for credits to everyone who helped me or supported me during the developing time of this hack:

DJGrisner:
Thank you for volunteering to contribute into the hack. Without your help I wouldn't have been able to implement the ideas I had for the menu, podium and title screens, as well as the custom sprites that you created. I also can't thank you enough for the wonderful work you did with the Soundtrack! It really elevates the hack to a whole new level.

Cocatriz:
Thank you very much for your patience and testing the hack a lot. Without your feedback, the hack gameplay wouldn't be as as polished as it ended. Your insight was invaluable in making sure even people who are really good at the game can enjoy it as well.

R4M0N: Thanks a lot for your expansion patch that allows the hack to have a more distinct flavor and allow me to get more creative with the color palettes chosen and also enhance some tracks further than they were intended.

IceSan: Thank you big time for creating the Mirror Mode Patch and the Turbo mode patch. These additions really add more to the replay value of the game. I also thank you a bunch for the debugging sessions as well as technical questions I had when making the hack!

Stifu: Thank you for developing Epic Edit. It is truly a wonderful tool on how easy it is to make our own tracks and how user friendly it is. Thanks a lot for the technical issues I also encountered as well over the past years when making the hack.

Mr. L: Thanks a lot for the insight and help when I encountered technical issues and questions when developing the hack, as well as on how to implement the ranking system changes and other weird questions I happened to have at the time!

Dirtbag: Thanks for your support and technical questions, as well as feedback I had in the early stages when developing the hack!

ScouB: Thank you for also addressing and helping me for any questions I had with the inner workings of the game.

Laura: Thank you for creating the beautiful artwork of the hack! You can check her other works here: https://laurie.ink/projects/XgEoey

Emilio: Thank you for creating the 3 album covers used for the soundtrack!

BLaBrake: Thanks for the SNES; it helped me test this hack on real hardware (and I hope you don't mind I remixed some tracks I did for you on Sour Music Kart!)

DarthMarino: Thank you for the instructions on how to remove the black line that covers 3 pixels of the background!

Gustavo: Thanks for all of these years we spent testing the battle mode in the after office hours! As well as helping recording all the 2P player footage I needed for the videos.

Lafungo & KVD: Thank you Lafungo for coming up with the name for the hack; I really had a hard time deciding what to name it! Also thanks to you and KVD for providing feedback in the VS. Mode of the mod.

Matrizzle: Thanks a lot for finding out at first on how to edit the beach tide water animation!

SMK Championships & FFSMK: Thanks to the community for their feedback, as well as play testing the hack on several occasions after their event concluded!

SMK Workshop: Thanks to the members who provided support & feedback all this time!

... and many others that have indirectly or directly helping in making the hack!